package com.example.pr3_task4;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonChangeText = findViewById(R.id.buttonChangeText);
        TextView textView = findViewById(R.id.textView);

        buttonChangeText.setOnClickListener(v -> {
            textView.setText("Вы нажали на кнопку!");
            textView.setTextColor(Color.RED);
        });
    }
}
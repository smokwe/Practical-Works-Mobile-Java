package com.example.pr3_task5;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private boolean isClicked = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);

        button.setOnClickListener(v -> {
            if (!isClicked) {
                button.setText("Нажато!");
                button.setTextColor(Color.BLUE);
                button.setShadowLayer(10, 5, 5, Color.GRAY);
            } else {
                button.setText("Нажми снова");
                button.setTextColor(Color.RED);
                button.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
            }
            isClicked = !isClicked;
        });
    }
}
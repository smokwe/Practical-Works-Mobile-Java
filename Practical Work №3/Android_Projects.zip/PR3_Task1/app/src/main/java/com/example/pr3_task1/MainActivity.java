package com.example.pr3_task1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editTextName = findViewById(R.id.editTextName);
        Button buttonGreet = findViewById(R.id.buttonGreet);
        TextView textViewGreeting = findViewById(R.id.textViewGreeting);

        buttonGreet.setOnClickListener(v -> {
            String name = editTextName.getText().toString().trim();
            textViewGreeting.setText("Привет, " + name + "!");
        });
    }


}
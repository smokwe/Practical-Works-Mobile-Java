package com.example.pr3_task3;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editTextBorderWidth = findViewById(R.id.editTextBorderWidth);
        Button buttonSetBorder = findViewById(R.id.buttonSetBorder);
        ImageView imageView = findViewById(R.id.imageView);

        buttonSetBorder.setOnClickListener(v -> {
            int borderWidth = Integer.parseInt(editTextBorderWidth.getText().toString().trim());
            GradientDrawable border = (GradientDrawable) imageView.getBackground();
            border.setStroke(borderWidth, getResources().getColor(android.R.color.black));
        });
    }
}